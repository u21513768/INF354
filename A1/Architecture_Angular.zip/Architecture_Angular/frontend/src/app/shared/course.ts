export interface Course {
    courseId: Number;
    name:String;
    duration:String;
    description:String;
}