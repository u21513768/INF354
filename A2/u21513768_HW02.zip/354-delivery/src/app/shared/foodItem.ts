export interface FoodItem {
    restaurantName: string;
    dishName: string;
    type: string;
    ratings: number;
    distance: number;
    price: number;
    // Add more properties if needed
  }
  